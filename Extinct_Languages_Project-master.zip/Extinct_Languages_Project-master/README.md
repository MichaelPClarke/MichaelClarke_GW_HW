# Extinct_Languages_Project
Looking at extinct languages in North America, Canada and Mexico
